<h2 align="centre"><i><b>🎀TECHNO MINDZ🎀</i></b></h2>

# ViewFilters Won't Work

<p align="center"><a href="https://t.me/technomindzchat"><img src="https://telegra.ph/file/b417bdd01331179d5787c.jpg" width="300"></a></p>

## Introduction

![Typing SVG](https://readme-typing-svg.herokuapp.com/?lines=Welcome+To+Techno+Mindz!;A+FILTER+BOT+LIKE+BETTERFILTERBOT;Created+by+RAVINANDAN!;A+simple+and+a+powerful+Bot!;Don't+Forget+To+Subcribe;Techno+Mindz+in+YouTube;)
</p>
</h1>
<a href="https://www.youtube.com/c/TechnoMindz">
  <img src="https://img.shields.io/badge/𝚂𝚄𝙱𝚂𝙲𝚁𝙸𝙱𝙴-red?logo=youtube" width="150">

## SUPPORT
## IF YOU NEED ANY ASSISTANCE FEEL FREE TO CONTACT
## YOUTUBE  [SUPPORT_CHANNEL](https://t.me/technomindzchat)
## Contact [OWNER](https://t.me/technomindzyt)
  
### Features
* Nearly unlimited filters
* Supports all type of filters(Including Alert Button Filter).
* Can save button filters directly (Rose Bot Feature)
* Supports multiple PM connections
* And all other features of a Filter Bot :D


#### Deploy the bot and start adding your filters :)


## How to use the bot
* Add bot to your group with admin rights.

* Add your filters :)

## Modal Bot 
  * [<i><b>@TMBETTERFILTERBOT</i></b>](https://t.me/tmbetterfilterbot)

## Bot Commands

(You need to be an admin or Auth User in order to use these commands)

> Filter Commands
* `/add <filtername> <filtercontent>`  -  To add your filter. You can also reply to your content with /add command.

* `/del <filtername>`  -  Delete your filter.

* `/delall`  -  Delete all filters from group. (Group Owner Only!)

> Connection Commands
* `/connect groupid`  -  Connects your group to PM. You can also simply use, `/connect` in groups.

* `/connections`  -  Manage your connections. (only in PM)

> Extras
* `/status`  -  Shows current status of your bot (Auth User Only)

* `/id`  -  Shows ID information

* `/info <userid>`  -  Shows User Information. Also use `/info` as reply to some message for their details!



## Any bugs or errors or suggestions, report at [TMSUPPORT](https://telegram.dog/TECHNOMINDZCHAT)


### Deploy to Heroku

<details><summary>Deploy To Heroku</summary>
<p>
<br>
<a href="https://heroku.com/deploy?template=https://github.com/TechnoMindz/FilterBot">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
</a>
</p>
</details>

  ## CREATED BY
 
* [RAVINANDAN](https://t.me/TechnoMINDZYT)
## Selling The Codes To Other People For Money Is *Strictly Prohibited*.


## Support
[![telegram badge](https://img.shields.io/badge/Telegram-Group-30302f?style=flat&logo=telegram)](https://telegram.dog/technomindzchat)
[![telegram badge](https://img.shields.io/badge/Telegram-Channel-30302f?style=flat&logo=telegram)](https://telegram.dog/Tmmainchannel)




## Thanks to 

 - Thanks To [꧁𓊈𒆜🆁🅰🆅🅸🅽🅰🅽🅳🅰🅽𒆜𓊉꧂](https://t.me/TechnoMindzyT) for Their Awesome [Unlimited Filter Bot]

# FilterBot
